using StatsFuns: normcdf, normpdf
import ForneyLab: slug, requiresBreaker, breakerParameters, outboundType, isApplicable, collectSumProductNodeInbounds, removePrefix
using ForneyLab: SoftFactor, @ensureVariables, addNode!, associate!, generateId, unsafeMeanCov, unsafeWeightedMeanPrecision, unsafeMode, assembleClamp!, SPEqualityGFactor, matches, variateType

include("factor_nodes/chance_constraint.jl")
include("factor_nodes/point_mass_constraint.jl")
include("update_rules/chance_constraint.jl")
include("update_rules/point_mass_constraint.jl")
include("engines/julia/update_rules/chance_constraint.jl")
include("engines/julia/update_rules/point_mass_constraint.jl")


# Overwrite some ForneyLab-defined functions to handle constraint-nodes
function isApplicable(::Type{SPEqualityGFactor}, input_types::Vector{Type})
    nothing_inputs = 0
    factor_inputs = 0
    gaussian_inputs = 0

    for input_type in input_types
    	matches(input_type, Message{PointMass}) && return false # Rule does not apply to pointmass
        if input_type == Nothing
            nothing_inputs += 1
        elseif matches(input_type, Message{Gaussian})
            gaussian_inputs += 1
        elseif matches(input_type, Message{FactorNode})
            factor_inputs += 1
        end
    end

    return (nothing_inputs == 1) && (factor_inputs == 1) && (gaussian_inputs == 1)
end

removePrefix(tup::Tuple) = string(tup)
removePrefix(vect::Vector) = string(vect)
