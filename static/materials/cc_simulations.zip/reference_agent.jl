# "initializeAgent" is a closure that returns the "infer" and "act"
# functions for interacting with the agent.
function initializeAgent()
    marginals = Dict{Symbol, ProbabilityDistribution}()

    function infer(x_hat_t::Float64, m_w::Vector{Float64})
        data = Dict(:x_hat_t => x_hat_t,
                    :m_w     => m_w) # Future wind mean

        # Initialize variational beliefs
        marginals[:u_t] = ProbabilityDistribution(Univariate, PointMass, m=0.0)
        for k = 1:T-1
            marginals[:u_t_plus_*k] = ProbabilityDistribution(Univariate, PointMass, m=0.0)            
        end

        # Initialize messages
        messages_x = initX()
        
        for i=1:10 # Iterations per time step
            stepX!(data, marginals, messages_x)
            stepU!(data, marginals)
        end

        return unsafeMeanCov(marginals[:x_t_plus_1]) # Return posterior belief over next state for convergence check
    end
    
    marginals[:u_t] = ProbabilityDistribution(PointMass, m=0.0) # Register initial action
    act() = unsafeMode(marginals[:u_t]) # Choose the mode of the control state as action

    return (infer, act)
end