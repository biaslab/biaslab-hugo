This file contains minimal instructions to get the accompanying demos running with Jupyter Notebook, Julia and ForneyLab. Pre-executed demos are also available as HTML files.

# Install Julia
In order to install the Julia language (v1.3.0 or higher), follow the platform-specific instructions at https://julialang.org/downloads/platform.html

# Install Jupyter Notebook
Jupyter notebook is a framework for running Julia (among other languages) in a browser environment. It is especially well suited for showing demo applications and interactive experimentation (i.e. playing around). In order to install Jupyter Notebook, follow the instructions at https://jupyter.readthedocs.io/en/latest/install.html

# Install required packages
The demos require some packages to be imported in Julia. Open Julia
```
$ julia
```
and enter the package prompt by typing a closing bracket
```
> ]
```
We will install several packages:

- `IJulia.jl` loads the Julia kernel for Jupyter Notebooks; 
- `PyPlot.jl` is a Julia wrapper around `matplotlib.pyplot`; 
- `JLD.jl` is a library for saving and loading Julia variables; 
- `ProgressMeter.jl` tracks progress of long-running operations;
- `ForneyLab.jl` is our in-house developed package for message passing on factor graphs. Make sure to install v0.11.3 or higher, otherwise the demos might not work.

```
] add IJulia
] add PyPlot
] add JLD
] add ProgressMeter
] add ForneyLab
```

# Install GraphViz (optional)
Graph visualization in ForneyLab depends upon the `GraphViz` package. Although the demos do not use graph visualization, you might still want it. For Ubuntu:
```
$ sudo apt-get install graphviz
```

# Run the demo
Navigate to the directory where you placed the demos and start Jupyter Notebook
```
~/Demos$ jupyter notebook
```
A browser window will open, and you can select the demo you wish to run.