# System parameters
m_w(t::Int64) = 5<=t<10 ? -1.0 : 0.0 # Wind mean over time

# "initializeWorld" is a closure that returns the "execute" and "observe"
# functions for interacting with the simulated environment.
function initializeWorld()
    x_0 = 0.0 # Initial position
    
    x_t = x_0
    x_t_plus = x_0
    function execute(a_t::Float64, m_w_t::Float64) # Execute the action
        x_t_plus = x_t + a_t + m_w_t + sqrt(v_w)*randn() # Update elevation
                
        x_t = x_t_plus # Prepare for next step

        return nothing
    end

    observe() = x_t # Observe the current state

    return (execute, observe)
end