function plotControlLaw(x_hat, a)
    plot(x_hat, a, color="black")
    plot([1.0, 1.0], extrema(a), color="black", linestyle="--")
    grid("on")
    xlabel("Elevation (x)")
    ylabel("Control (a)")
    # title("T=$T; eps=$(epsilon); v_w=$(v_w); lambda=$(lambda)")
    xlim(extrema(x_hat))
    ylim(extrema(a))
end

function plotTrajectory(x_hat, a, per_n)
    figure(figsize=(7,10))

    # Wind mean (same for all runs)
    subplot(4, 1, 1)
    # title("T=$T; eps=$(epsilon); N=$N; v_w=$(v_w); lambda=$(lambda); E_avg=$(E_avg)")
    scatter(0:L, m_w.(0:L), color="black")
    xlim(0,L)
    grid("on")
    ylabel("E[w]")

    # Trajectory per run
    subplot(4, 1, 2)
    plot([0,L], [1.0, 1.0], color="black", linestyle="--")
    for n=1:per_n:N
        plot(0:L, x_hat[:,n], color="black", alpha=0.1)
    end
    xlim(0,L)
    ylim(0,5.5)
    grid("on")
    ylabel("Elevation (x)")

    # Control signal per run
    subplot(4, 1, 3)
    for n=1:per_n:N
        plot(0:L, a[:,n], color="black", alpha=0.1)
    end
    xlim(0,L)
    ylim(-1.5,2.5)
    grid("on")
    ylabel("Control Signal (a)")

    # Violation ratio (of runs) over time
    subplot(4, 1, 4)
    plot([0,L], [epsilon, epsilon], color="black", linestyle="--")
    r = vec(mean(x_hat .< 1.0, dims=2))
    scatter(0:L, r, color="black")
    xlim(0,L)
    ylim(0,0.015)
    grid("on")
    xlabel("Time (t)")
    ylabel("Target Violation Ratio")
end

function plotBeliefs(b)
    for n=1:per_n:N # Trajectory
        b_n = b[:,n]
        m_b = [b_t[1] for b_t in b_n]
        v_b = [b_t[2] for b_t in b_n]

        subplot(2, 1, 1)
        plot(0:L, m_b, color="black", alpha=0.3)
        fill_between(0:L, m_b-sqrt.(v_b), m_b+sqrt.(v_b), color="black", alpha=0.1)

        subplot(2, 1, 2)
        tr_mom = truncatedGaussianMoments.(m_b, v_b, 1.0, Inf)
        eps_hat = [1.0 - tr_mom_t[1] for tr_mom_t in tr_mom]
        plot(0:L, eps_hat, color="black", alpha=0.3)
    end

    subplot(2, 1, 1)
    xlim(0,L)
    grid("on")
    ylabel("Belief q(x_t+1)")

    subplot(2, 1, 2)
    xlim(0,L)
    grid("on")
    ylabel("Unsafe Mass")
    xlabel("Time (t)")
end