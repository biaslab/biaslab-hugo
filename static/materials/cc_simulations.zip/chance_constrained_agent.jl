# "initializeAgent" is a closure that returns the "infer" and "act"
# functions for interacting with the agent.
function initializeAgent()
    marginals = Dict{Symbol, ProbabilityDistribution}()

    function infer(x_hat_t::Float64, m_w::Vector{Float64})
        data = Dict(:x_hat_t => x_hat_t,
                    :m_w     => m_w) # Future wind mean

        # Initialize variational beliefs
        marginals[:u_t] = ProbabilityDistribution(Univariate, PointMass, m=0.0)
        for k = 1:T-1
            marginals[:u_t_plus_*k] = ProbabilityDistribution(Univariate, PointMass, m=0.0)            
        end

        # Initialize messages
        messages_x = initX()
        
        for i=1:100 # Iterate at most this many times per time-step
            stepX!(data, marginals, messages_x)
            stepU!(data, marginals)
            
            # Check convergence
            (m_b, v_b) = unsafeMeanCov(marginals[:x_t_plus_1])
            (Phi_G, _, _) = truncatedGaussianMoments(m_b, v_b, 1.0, Inf)
            if (i > 10) && (1.0 - Phi_G) < 1.01*epsilon # Iterate at least ten times
                break # Break the loop if the belief is sufficiently corrected
            end
        end

        return unsafeMeanCov(marginals[:x_t_plus_1]) # Return posterior belief over next state for convergence check
    end
    
    marginals[:u_t] = ProbabilityDistribution(PointMass, m=0.0) # Register initial action
    act() = unsafeMode(marginals[:u_t]) # Choose the mode of the control state as action

    return (infer, act)
end