# This file defines the agent's internal beliefs over the external dynamics, which correspond accurately by directly using the functions from environment.jl

# Internal dynamic model
function g(s_t_min::Vector{Float64}) # Transition function modeling transition due to gravity and friction
    s_t = Vector{Float64}(undef, 2)
    s_t[2] = s_t_min[2] + Fg(s_t_min[1]) + Ff(s_t_min[2]) # Update velocity
    s_t[1] = s_t_min[1] + s_t[2] # Update position

    return s_t
end
Jg(s_t_min::Vector{Float64}) = # Jacobi matrix for g(.)
    [Fg_prime(s_t_min[1])+1 Ff_prime(s_t_min[2])+1;
     Fg_prime(s_t_min[1])   Ff_prime(s_t_min[2])+1]

h(u::Vector{Float64}) = [0.0, Fa(u[1])] # Function for modeling engine control
Jh(u::Vector{Float64}) = reshape([0.0, Fa_prime(u[1])],2,1) # Jacobi matrix for h()
h_inv(delta_s_dot::Vector{Float64}) = [atanh(clamp(delta_s_dot[2], -c_a+1e-3, c_a-1e-3)/c_a)] # Inverse engine force, from change in state to corresponding engine force

# Because states of the agent are unknown to the world, we wrap them in a comprehension.
# The comprehension only returns functions for interacting with the agent.
# Internal beliefs cannot be directly observed, and interaction is only allowed through the Markov blanket
function initializeAgent()
    m_u = [[0.0] for t=1:T] # Control prior statistics
    V_u = [mat(huge) for t=1:T]

    x_target = [0.5, 0.0] # Goal state
    sigma = 1e-4*diageye(2) # Goal prior variance
    tau = 20 # Time at which goal should be reached
    m_x = Vector[]
    V_x = AbstractMatrix[]
    for t=1:T # Set prior goal statistics
        if t < tau
            push!(m_x, x_target)
            push!(V_x, huge*diageye(2)) # Large variance (don't care about intermediate states)
        else
            push!(m_x, x_target)
            push!(V_x, sigma) # Goal prior variance
        end
    end

    # Initialize messages and marginals dictionary
    messages = init()
    marginals = Dict{Symbol, ProbabilityDistribution}()
    function infer(a_t::Float64, y_hat_t::Vector{Float64}, t::Int64)
        m_u[t] = [a_t] # Register action with the generative model
        V_u[t] = mat(tiny) # Clamp control prior to performed action

        m_x[t] = y_hat_t # Register observation with the generative model
        V_x[t] = tiny*diageye(2) # Clamp goal prior to observation

        data = Dict(:m_u => m_u, :V_u => V_u, :m_x => m_x, :V_x => V_x)
        step!(data, marginals, messages)
    end

    # Choose the mode of the current control state as action
    function act(t::Int64)
        if t > 1
            a_t = mode(marginals[pad(:u, t)])[1]
        else
            a_t = 0.0 # Initial action
        end
    end

    slide() = () # Slide is implicit

    return (infer, act, slide)    
end