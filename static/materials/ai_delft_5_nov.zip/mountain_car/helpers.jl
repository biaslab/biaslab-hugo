function plotLandscape()
    subplot(211)
    y_hat = -1.0:0.01:1.0
    Fg_y_hat = [Fg(y_k) for y_k in y_hat]
    plot(y_hat, Fg_y_hat, color="black", lw=2)
    grid("on")
    xlabel(L"Position $(y)$")
    ylabel(L"Gravitational Force $(F_g)$")

    subplot(212)
    a_hat = -10.0:0.1:10.0
    Fa_a_hat = [Fa(a_k) for a_k in a_hat]
    plot(a_hat, Fa_a_hat, color="black", lw=2)
    grid("on")
    ylim(-0.05, 0.05)
    xlabel(L"Action $(a)$")
    ylabel(L"Engine Force $(F_a)$")

    tight_layout()
end

function plotTrajectory(a::Vector{Float64}, x::Vector{Vector{Float64}}; color="black")
    subplot(211)
    plot(1:T, [x[t][1] for t=1:T], color=color, label=L"Observed position $(\hat{y})$", lw=2)
    plot(1:T, [x[t][2] for t=1:T], color=color, linestyle="--", label=L"Observed velocity $(\hat{\dot{y}})$", lw=2)
    grid("on")
    ylim(-1.5,1.0)
    PyPlot.plt[:xticks](0:5:T,["" for _=1:(Int64(T/5)+1)])
    legend(loc=4)

    subplot(212)
    Fa_eff = [Fa(a[t]) for t=1:T]
    plot(1:T, Fa_eff, color=color, lw=2)
    grid("on")
    ylabel(L"Engine Force $(F_a)$")
    ylim(-0.05,0.05)

    xlabel(L"Time $(t)$")

    tight_layout()
end

pad(sym::Symbol, t::Int) = sym*:_*Symbol(lpad(t,2,'0')) # Left-pads a number with zeros, converts it to symbol and appends to sym