# This file defines the environmental process

c_a = 0.04 # Engine-force limit
Fa(a::Float64) = c_a*tanh(a) # Engine force as function of action
Fa_prime(a::Float64) = c_a-c_a*tanh(a)^2 # Derivative of engine force

c_f = 0.1 # Friction coefficient
Ff(y_dot::Float64) = -c_f*y_dot # Friction force as function of velocity
Ff_prime(y_dot::Float64) = -c_f # Derivative of friction force

g_a = 5
g_b = 5
g_c = 16
function Fg(y::Float64) # Gravitational force (horizontal component) as function of position
    if y < 0
        0.05*(-2*y - 1)
    else
        0.05*(-(1 + g_a*y^2)^(-0.5) - (y^2)*(1 + g_b*y^2)^(-3/2) - (y^4)/g_c)
    end
end
function Fg_prime(y::Float64) # Derivative of gravitational force
    if y < 0
        -0.1
    else
        0.05*((-4*y^3)/g_c + (g_a*y)/(1 + g_a*y^2)^1.5 + (3*g_b*y^3)/(1 + g_b*y^2)^(5/2) - (2*y)/(1 + g_b*y^2)^(3/2))
    end
end

# Because the states of the world are unknown to the agent, we wrap them in a comprehension.
# The comprehension returns only the functions for interacting with the world and not the hidden states.
# This way, we introduce a stateful world whose states cannot be directly observed.
function initializeWorld()
    y_0 = -0.5 # Initial position
    y_dot_0 = 0.0 # Initial velocity

    y_t_min = y_0
    y_dot_t_min = y_dot_0
    function execute(a_t::Float64)
        # Compute next state
        y_dot_t = y_dot_t_min + Fg(y_t_min) + Ff(y_dot_t_min) + Fa(a_t)
        y_t = y_t_min + y_dot_t
    
        # Reset state for next step
        y_t_min = y_t
        y_dot_t_min = y_dot_t
    end
    
    y_t = y_0
    y_dot_t = y_dot_0
    observe() = [y_t, y_dot_t]
        
    return (execute, observe)
end