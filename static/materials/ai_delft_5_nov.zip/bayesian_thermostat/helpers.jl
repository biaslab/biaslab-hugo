function plotTrajectory(a::Vector{Float64}, y::Vector{Float64})
    # Visualize observed variables
    subplot(211)
    plot(1:T, a, color="black", lw=2)
    grid("on")
    PyPlot.plt[:xticks](0:20:100,["" for _=1:6])
    ylabel(L"Velocity $(a)$")

    subplot(212)
    plot(1:T, y, color="black", lw=2)
    grid("on")
    ylabel(L"Temperature $(y)$")

    xlabel(L"Time $(t)$")

    tight_layout()
end

function plotLandscape()
    z_hat = 0.0:0.01:6.0
    y_hat = [temperature(z_k) for z_k in z_hat]
    plot(z_hat, y_hat, color="black", lw=2)
    grid("on")
    xlabel(L"Position $(z)$")
    ylabel(L"Temperature $(y)$")
end

function inspectSnippet(algo::String)
    println(algo[1:460])
    println("\n...\n")
    println(algo[end-198:end])
end