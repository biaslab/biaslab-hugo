# Environmental process parameters
source_temperature = 100.0 # Temperature at the heat source (z=0)
temperature(z::Float64) = source_temperature/(z^2 + 1.0) # Actual temperature profile; this function is hidden from the agent

# Because the states of the world are unknown to the agent, we wrap them in a comprehension.
# The comprehension returns only the functions for interacting with the world and not the hidden states.
# This way, we introduce a stateful world whose states cannot be directly observed.
function initializeWorld()
    z_0 = 2.0 # Initial position
    z_t_min = z_0
    function execute(a_t::Float64)
        z_t = z_t_min + a_t # Update position
        y_t = temperature(z_t) + sqrt(theta)*randn() # Report noisy temperature at current position
    
        z_t_min = z_t # Reset state
                
        return y_t
    end

    y_t = 0.0 # Predefine outcome variable
    observe() = y_t

    return (execute, observe)
end