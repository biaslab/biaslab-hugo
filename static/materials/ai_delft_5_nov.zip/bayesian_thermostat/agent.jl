# Because states of the agent are unknown to the world, we wrap them in a comprehension.
# The comprehension only returns functions for interacting with the agent.
# Internal beliefs cannot be directly observed, and interaction is only allowed through the Markov blanket
function initializeAgent()
    m_u = zeros(T) # Control prior statistics
    v_u = 0.01*ones(T)

    x_target = 4.0 # Goal temperature
    sigma = 0.01 # Goal prior variance
    m_x = x_target*ones(T) # Set goal priors
    v_x = sigma*ones(T)

    function infer(a_t::Float64, y_hat_t::Float64, t::Int64)
        m_u[t] = a_t # Register action with the generative model
        v_u[t] = tiny # Clamp control prior to performed action

        m_x[t] = y_hat_t # Register observation with the generative model
        v_x[t] = tiny # Clamp goal prior to observation

        data = Dict(:m_u => m_u, :v_u => v_u, :m_x => m_x, :v_x => v_x)
        marginals = step!(data)
    end
    
    marginals = Dict{Symbol, ProbabilityDistribution}() # Predefine marginals dictionary
    function act(t::Int64)
        if t > action_onset # Actions are only allowed after a specific time
            a_t = mode(marginals[:u_*t]) # Choose the mode of the current control state as action
        else
            a_t = 0.0
        end

        return a_t
    end

    slide() = () # Slide is implicit

    return (infer, act, slide)
end