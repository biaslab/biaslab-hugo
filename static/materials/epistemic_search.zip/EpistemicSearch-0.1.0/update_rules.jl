using ForneyLab: unsafeLogMean, softmax


@structuredVariationalRule(:node_type     => Transition,
                           :outbound_type => Message{Categorical},
                           :inbound_types => (Nothing, Message{PointMass}, ProbabilityDistribution),
                           :name          => SVBTransitionOutVPD)

@structuredVariationalRule(:node_type     => Transition,
                           :outbound_type => Message{Categorical},
                           :inbound_types => (Message{PointMass}, Nothing, ProbabilityDistribution),
                           :name          => SVBTransitionIn1PVD)

@marginalRule(:node_type     => Transition,
              :inbound_types => (Message{PointMass}, Message{Categorical}, ProbabilityDistribution),
              :name          => MTransitionPCD)

@marginalRule(:node_type     => Transition,
              :inbound_types => (Message{PointMass}, Message{PointMass}, ProbabilityDistribution),
              :name          => MTransitionPPD)

function ruleSVBTransitionOutVPD(   dist_out::Nothing,
                                    msg_in1::Message{PointMass},
                                    dist_a::ProbabilityDistribution{MatrixVariate})

    a = clamp.(exp.(unsafeLogMean(dist_a))*msg_in1.dist.params[:m], tiny, Inf)

    Message(Univariate, Categorical, p=a./sum(a))
end

function ruleSVBTransitionIn1PVD(   msg_out::Message{PointMass},
                                    dist_in1::Nothing,
                                    dist_a::ProbabilityDistribution{MatrixVariate})

    a = clamp.(exp.(unsafeLogMean(dist_a))'*msg_out.dist.params[:m], tiny, Inf)

    Message(Univariate, Categorical, p=a./sum(a))
end

function ruleMTransitionPCD(msg_out::Message{PointMass},
                            msg_in1::Message{Categorical},
                            dist_a::ProbabilityDistribution{MatrixVariate})

    B = Diagonal(msg_out.dist.params[:m])*exp.(unsafeLogMean(dist_a))*Diagonal(msg_in1.dist.params[:p])

    ProbabilityDistribution(Multivariate, Contingency, p=B./sum(B))
end

function ruleMTransitionPPD(msg_out::Message{PointMass},
                            msg_in1::Message{PointMass},
                            dist_a::ProbabilityDistribution{MatrixVariate})

    B = Diagonal(msg_out.dist.params[:m])*exp.(unsafeLogMean(dist_a))*Diagonal(msg_in1.dist.params[:m])

    ProbabilityDistribution(Multivariate, Contingency, p=B./sum(B))
end