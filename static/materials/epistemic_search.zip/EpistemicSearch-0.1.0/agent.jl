using ForneyLab: softmax #, unsafeMean, unsafeMode


function evaluatePolicies(A, B, C, D, model::String)
    # C_t = [C, C]
    C_t = [ones(16)/16, C]

    # Evaluate all policies
    F = zeros(4,4)
    for i in 1:4  # First move
        for j = 1:4  # Second move
            data = Dict(:u       => [B[i], B[j]],
                        :A       => A,
                        :C       => C_t,
                        :D_t_min => D)

            if model=="constrained"
                marginals = Dict{Symbol, ProbabilityDistribution}(
                    :y_1 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[1]),
                    :y_2 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[2]))
            
                for n=1:20
                    stepPlanConstrainedX!(data, marginals)
                    stepPlanConstrainedY!(data, marginals)
                end
            elseif model=="reference"
                marginals = stepPlanReference!(data)
            end
        
            F[i, j] = getfield(Main, Symbol("freeEnergyPlan$(uppercasefirst(model))"))(data, marginals)
        end
    end

    return F./log(2) # Convert to bits
end

function evaluateValues(A, B, C, D)
    # C_t = [C, C]
    C_t = [ones(16)/16, C]

    # Evaluate all policies
    G = zeros(4,4) # Information gain
    R = zeros(4,4) # Information risk
    E = zeros(4,4) # Extrinsic value
    S = zeros(4,4) # Surprise
    for i in 1:4  # First move
        for j = 1:4  # Second move
            data = Dict(:u       => [B[i], B[j]],
                        :A       => A,
                        :C       => C_t,
                        :D_t_min => D)

            marginals = Dict{Symbol, ProbabilityDistribution}(
                :y_1 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[1]),
                :y_2 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[2]))

            for n=1:20
                stepPlanX!(data, marginals)
                stepPlanY!(data, marginals)
            end

            # Construct executed policy and resulting predicted outcomes
            u_hat = [i, j]
            y_hat = Vector{Int64}(undef, T)
            for k=1:T
                (_, y_hat[k]) = findmax(marginals[:y_*k].params[:m])
            end

            (G[i,j], R[i,j], E[i,j]) = valueTermsPlan(data, marginals)
            S[i,j] = evaluateSurprise(A, B, D, y_hat, u_hat)
        end
    end

    return (G, R, E, S)
end

function predict(A, B_k, D_k_min::Vector{Float64}, y_k::Int64)
    # Convert observation to one-hot
    y_k_vec = zeros(16)
    y_k_vec[y_k] = 1.0
    
    data = Dict(:A       => A,
                :u_k     => B_k,
                :D_k_min => D_k_min,
                :y_k     => y_k_vec)
    messages = Array{Message}(undef, 4)
    marginals = Dict()
    
    messages[1] = ruleSPCategoricalOutNP(nothing, Message(Multivariate, PointMass, m=data[:D_k_min]))
    messages[2] = ruleSPTransitionOutNCP(nothing, messages[1], Message(MatrixVariate, PointMass, m=data[:u_k]))
    messages[3] = ruleSPTransitionOutNCP(nothing, messages[2], Message(MatrixVariate, PointMass, m=data[:A]))
    messages[4] = ruleSPTransitionIn1PNP(Message(Multivariate, PointMass, m=data[:y_k]), nothing, Message(MatrixVariate, PointMass, m=data[:A]))

    marginals[:x_k] = messages[2].dist * messages[4].dist
    
    pred_y_k = messages[3].dist
    pred_x_k = marginals[:x_k]
    
    return (pred_y_k, pred_x_k)
end

function evaluateSurprise(A, B, D, y::Vector{Int64}, u::Vector{Int64})
    T = length(y)
    D_k_min = D
    S = Vector{Float64}(undef, T)
    for k=1:T
        (pred_y_k, pred_x_k) = predict(A, B[u[k]], D_k_min, y[k])
        
        S[k] = -log(pred_y_k.params[:p][y[k]])/log(2) # Evaluate surprise at observed value, in bits
        D_k = pred_x_k.params[:p]
        
        D_k_min = D_k # Reset for next step
    end
    
    return sum(S)/log(2) # Return total surprise in bits
end

function initializeAgent(A, B, C, D)

    function planConstrained()
        # Evaluate all policies
        F = zeros(4,4)
        for i in 1:4  # First move
            for j = 1:4  # Second move
                data = Dict(:u       => [B[i], B[j]],
                            :A       => A,
                            :C       => C_t,
                            :D_t_min => D_t_min)

                marginals = Dict{Symbol, ProbabilityDistribution}(
                    :y_1 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[1]),
                    :y_2 => ProbabilityDistribution(Multivariate, PointMass, m=C_t[2]))
                
                for n=1:20
                    stepPlanConstrainedX!(data, marginals)
                    stepPlanConstrainedY!(data, marginals)
                end
            
                F[i, j] = freeEnergyPlanConstrained(data, marginals)
            end
        end

        return F./log(2) # Return free energy in bits
    end

    function planEFE()
        # Evaluate all policies
        Q = zeros(4,4)
        for i in 1:4 # First move
            x_t_hat = B[i]*D_t_min # Expected state
            y_t_hat = A*x_t_hat # Expected outcome
        
            # We follow Eq. D.2 in da Costa (2021) "Active inference on discrete state-spaces: a synthesis",
            # which algebraically is the same as Friston (2015), but reads better.
            predicted_uncertainty_t = diag(A' * log.(A.+eps()))' * x_t_hat # Friston (for reference): ones(16)' * (A.*log.(A.+eps())) * x_t_hat
            predicted_divergence_t = transpose( log.(y_t_hat.+eps()) - log.(C_t[1].+eps()) ) * y_t_hat
            Q_t = predicted_uncertainty_t - predicted_divergence_t

            for j in 1:4 # Second move
                x_t_plus_hat = B[j]*x_t_hat # Expected state
                y_t_plus_hat = A*x_t_hat # Expected outcome

                predicted_uncertainty_t_plus = diag(A' * log.(A.+eps()))' * x_t_plus_hat
                predicted_divergence_t_plus = transpose( log.(y_t_plus_hat.+eps()) - log.(C_t[2].+eps()) ) * y_t_plus_hat
                Q_t_plus = predicted_uncertainty_t_plus - predicted_divergence_t_plus

                Q[i, j] = Q_t + Q_t_plus
            end
        end
        
        return -Q./log(2) # Return expected free energy per policy in bits
    end

    function act(F::Matrix{Float64})
        # We include policy selection in the act function for clearer code; procedurally, policy selection belongs in the plan step
        p = softmax(vec(-100*F)) # Determine policy probabilities with high precision (max selection)
        S = reshape(sample(ProbabilityDistribution(Categorical, p=p)), 4, 4) # Reshaped policy sample
        (_, pol) = findmax(S)

        return pol[1] # Return first action of policy
    end

    D_t_min = D
    # C_t = [C, C]
    C_t = [ones(16)/16, C]
    function slide(a_t::Int64, o_t::Vector{Float64})
        # Estimate state
        data = Dict(:B_t     => B[a_t],
                    :A       => A,
                    :o_t     => o_t,
                    :D_t_min => D_t_min)
        marginals = stepSlide!(data)
        D_t_min = ForneyLab.unsafeMean(marginals[:x_t]) # Reset prior state statistics
        
        # Shift goals for next move
        C_t = circshift(C_t, -1)
        C_t[end] = C
    end

    return (planConstrained, planEFE, act, slide)
end