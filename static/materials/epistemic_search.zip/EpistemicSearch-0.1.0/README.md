The current repository contains the source code for generating the images of the paper "Active Inferene and Epistemic Value in Graphical Models", by Thijs van de Laar, Magnus Koudahl, Bart van Erp and Bert de Vries; for publication in Frontiers in Robotics and AI. The current `README.md` file contains minimal instructions to get the accompanying demos running with Jupyter Notebook, Julia and ForneyLab.

# Install Julia
In order to install the Julia language (v1.6.4), follow the platform-specific instructions at https://julialang.org/downloads/platform.html

# Install Jupyter Notebook
Jupyter notebook is a framework for running Julia (among other languages) in a browser environment. It is especially well suited for showing demo applications and interactive experimentation (i.e. playing around). In order to install Jupyter Notebook, follow the instructions at https://jupyter.readthedocs.io/en/latest/install.html

# Install required packages
The demos require some packages to be imported in Julia. Open Julia
```
$ julia
```
and enter the package prompt by typing a closing bracket
```
julia> ]
```
Next, activate the virtual environment
```
(v1.6) pkg> activate .
```
and instantiate the required packages
```
(EpistemicSearch) pkg> instantiate
```

# Run the demo
Exit Julia, navigate to the root directory and start a Jupyter server
```
~/EpistemicSearch$ jupyter notebook
```
A browser window will open, and you can select the demo you wish to run.

# License
(c) 2022 Thijs van de Laar