function plotLandscape()
    figure(figsize=(6.4, 5.0))

    subplot(211)
    y_hat = -1.0:0.01:1.0
    Fg_y_hat = [Fg(y_k) for y_k in y_hat]
    plot(y_hat, Fg_y_hat, color="black")
    grid("on")
    xlabel(L"Position $(\phi)$")
    ylabel(L"Gravitational Force $(F_g)$")

    subplot(212)
    a_hat = -10.0:0.1:10.0
    Fa_a_hat = [Fa(a_k) for a_k in a_hat]
    plot(a_hat, Fa_a_hat, color="black")
    grid("on")
    ylim(-0.05, 0.05)
    xlabel(L"Action $(a)$")
    ylabel(L"Engine Force $(F_a)$")

    tight_layout()
end

function plotTrajectory(a::Vector{Float64}, y::Vector{Vector{Float64}}; color="black", show_legend=true)
    fig = gcf()
    fig[:set_size_inches](6.4, 5.0)

    subplot(211)
    plot(1:N, [y[t][1] for t=1:N], color=color, label=L"Position $(\phi)$")
    plot(1:N, [y[t][2] for t=1:N], color=color, linestyle="--", label=L"Velocity $(\dot{\phi})$")
    grid("on")
    ylabel("Trajectory")
    ylim(-1.5,1.0)
    PyPlot.plt[:xticks](0:5:N,["" for _=1:(Int64(N/5)+1)])
    show_legend && legend(loc=4)

    subplot(212)
    Fa_eff = [Fa(a[t]) for t=1:N]
    plot(1:N, Fa_eff, color=color)
    grid("on")
    ylabel(L"Engine Force $(F_a)$")
    ylim(-0.05,0.05)

    xlabel(L"Time $(t)$")

    tight_layout()
end

function plotTrajectories(a::Vector{Float64}, y::Vector{Vector{Float64}}, a_naive::Vector{Float64}, y_naive::Vector{Vector{Float64}})
    figure(figsize=(9.0, 5.0))

    subplot(221)
    plot(1:N, [y[t][1] for t=1:N], color="black")
    plot(1:N, [y[t][2] for t=1:N], color="black", linestyle="--")
    grid("on")
    ylabel("Trajectory")
    ylim(-1.5,1.0)
    PyPlot.plt[:xticks](0:5:N,["" for _=1:(Int64(N/5)+1)])

    subplot(223)
    Fa_eff = [Fa(a[t]) for t=1:N]
    plot(1:N, Fa_eff, color="black")
    grid("on")
    ylabel(L"Engine Force $(F_a)$")
    ylim(-0.05,0.05)

    xlabel(L"Time $(t)$")

    subplot(222)
    plot(1:N, [y_naive[t][1] for t=1:N], color="black", label=L"Position $(\phi)$")
    plot(1:N, [y_naive[t][2] for t=1:N], color="black", linestyle="--", label=L"Velocity $(\dot{\phi})$")
    grid("on")
    ylim(-1.5,1.0)
    PyPlot.plt[:yticks](-1.5:0.5:1.0,["" for _=1:6])
    PyPlot.plt[:xticks](0:5:N,["" for _=1:(Int64(N/5)+1)])
    legend(loc=4)

    subplot(224)
    Fa_eff_naive = [Fa(a_naive[t]) for t=1:N]
    plot(1:N, Fa_eff_naive, color="black")
    grid("on")
    ylim(-0.05,0.05)
    PyPlot.plt[:yticks](-0.04:0.02:0.04,["" for _=1:5])

    xlabel(L"Time $(t)$")

    tight_layout()
end

pad(sym::Symbol, t::Int) = sym*:_*Symbol(lpad(t,2,'0')) # Left-pads a number with zeros, converts it to symbol and appends to sym

function findMessageIndex(schedule::Schedule, node_id::Symbol, outbound_interface_id::Union{Int64, Symbol})
    condensed_schedule = ForneyLab.condense(ForneyLab.flatten(schedule))
    for (idx, entry) in enumerate(condensed_schedule)
        node = entry.interface.node
        if (node.id == node_id) && (entry.interface == node.i[outbound_interface_id])
            return idx
        end
    end
    
    error("Message $node_id[$outbound_interface_id] could not be found in schedule")
end