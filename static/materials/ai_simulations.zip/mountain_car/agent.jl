# This file defines the agent's internal beliefs over the external dynamics, which correspond accurately by directly using the functions from environment.jl

# Internal dynamic model
function g(s_t_min::Vector{Float64}) # Transition function modeling transition due to gravity and friction
    s_t = Vector{Float64}(undef, 2)
    s_t[2] = s_t_min[2] + Fg(s_t_min[1]) + Ff(s_t_min[2]) # Update velocity
    s_t[1] = s_t_min[1] + s_t[2] # Update position

    return s_t
end
Jg(s_t_min::Vector{Float64}) = # Jacobi matrix for g(.)
    [Fg_prime(s_t_min[1])+1 Ff_prime(s_t_min[2])+1;
     Fg_prime(s_t_min[1])   Ff_prime(s_t_min[2])+1]

h(u::Vector{Float64}) = [0.0, Fa(u[1])] # Function for modeling engine control
Jh(u::Vector{Float64}) = reshape([0.0, Fa_prime(u[1])],2,1) # Jacobi matrix for h()
h_inv(delta_s_dot::Vector{Float64}) = [atanh(clamp(delta_s_dot[2], -c_a+1e-3, c_a-1e-3)/c_a)] # Inverse engine force, from change in state to corresponding engine force

# Because states of the agent are unknown to the world, we wrap them in a comprehension.
# The comprehension only returns functions for interacting with the agent.
# Internal beliefs cannot be directly observed, and interaction is only allowed through the Markov blanket
function initializeAgent()
    Epsilon = mat(huge) # Control prior variance
    m_u = [[0.0] for k=1:T] # Set control priors
    V_u = [Epsilon for k=1:T]

    x_target = [0.5, 0.0] # Goal state
    Sigma = 1e-4*diageye(2) # Goal prior variance
    m_x = [zeros(2) for k=1:T]
    V_x = [huge*diageye(2) for k=1:T]
    V_x[end] = Sigma # Set prior to reach goal at t=T

    m_s_t_min = [-0.5, 0.0] # Set initial brain state prior
    V_s_t_min = tiny*diageye(2)

    # Initialize messages and marginals dictionary
    messages = init()
    marginals = Dict{Symbol, ProbabilityDistribution}()
    function infer(upsilon_t::Float64, y_hat_t::Vector{Float64})
        m_u[1] = [upsilon_t] # Register action with the generative model
        V_u[1] = mat(tiny) # Clamp control prior to performed action

        m_x[1] = y_hat_t # Register observation with the generative model
        V_x[1] = tiny*diageye(2) # Clamp goal prior to observation

        data = Dict(:m_u       => m_u, 
                    :V_u       => V_u, 
                    :m_x       => m_x, 
                    :V_x       => V_x,
                    :m_s_t_min => m_s_t_min,
                    :V_s_t_min => V_s_t_min)

        step!(data, marginals, messages)
    end

    marginals[pad(:u, 2)] = ProbabilityDistribution(Multivariate, GaussianMeanVariance, m=[0.0], v=mat(tiny)) # Register initial action
    act() = mode(marginals[pad(:u, 2)])[1] # Choose the mode of the current control state as action

    function slide(slide_msg_idx=161)
        (m_s_t_min, V_s_t_min) = ForneyLab.unsafeMeanCov(messages[slide_msg_idx].dist) # Reset prior state statistics; note: message 22 is algorithm specific

        m_u = circshift(m_u, -1)
        m_u[end] = [0.0]
        V_u = circshift(V_u, -1)
        V_u[end] = Epsilon

        m_x = circshift(m_x, -1)
        m_x[end] = x_target
        V_x = circshift(V_x, -1)
        V_x[end] = Sigma
    end

    return (infer, act, slide)    
end