# Because states of the agent are unknown to the world, we wrap them in a comprehension.
# The comprehension only returns functions for interacting with the agent.
# Internal beliefs cannot be directly observed, and interaction is only allowed through the Markov blanket
function initializeAgent()
    epsilon = 0.01 # Control prior variance
    m_u = zeros(T) # Set control priors
    v_u = epsilon*ones(T)

    x_target = 4.0 # Goal temperature
    sigma = 0.01 # Goal prior variance
    m_x = x_target*ones(T) # Set goal priors
    v_x = sigma*ones(T)

    m_s_t_min = 0.0 # Set initial brain state prior
    v_s_t_min = huge

    messages = Vector{Message}(undef, 31) # Predefine messages array
    marginals = Dict{Symbol, ProbabilityDistribution}() # Predefine marginals dictionary
    function infer(upsilon_t::Float64, y_hat_t::Float64)
        m_u[1] = upsilon_t # Register action with the generative model
        v_u[1] = tiny # Clamp control prior to performed action

        m_x[1] = y_hat_t # Register observation with the generative model
        v_x[1] = tiny # Clamp goal prior to observation

        data = Dict(:m_u       => m_u, 
                    :v_u       => v_u, 
                    :m_x       => m_x, 
                    :v_x       => v_x, 
                    :m_s_t_min => m_s_t_min,
                    :v_s_t_min => v_s_t_min)

        step!(data, marginals, messages)
    end
    
    marginals[:u_2] = ProbabilityDistribution(PointMass, m=0.0) # Register initial action
    act() = mode(marginals[:u_2]) # Choose the mode of the control state as action

    function slide(slide_msg_idx=15)
        (m_s_t_min, v_s_t_min) = ForneyLab.unsafeMeanCov(messages[slide_msg_idx].dist) # Reset prior state statistics; note: message 22 is algorithm specific

        m_u = circshift(m_u, -1)
        m_u[end] = 0.0
        v_u = circshift(v_u, -1)
        v_u[end] = epsilon

        m_x = circshift(m_x, -1)
        m_x[end] = x_target
        v_x = circshift(v_x, -1)
        v_x[end] = sigma
    end

    return (infer, act, slide)
end