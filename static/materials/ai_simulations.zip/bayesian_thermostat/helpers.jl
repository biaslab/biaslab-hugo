function plotTrajectory(a::Vector{Float64}, y::Vector{Float64})
    # Visualize observed variables
    figure(figsize=(6.4, 5.0))

    subplot(211)
    plot(1:N, a, color="black")
    grid("on")
    ylim(-0.5, 4)
    PyPlot.plt[:xticks](0:20:100,["" for _=1:6])
    PyPlot.plt[:yticks](0:4)
    ylabel(L"Velocity $(a)$")

    subplot(212)
    plot(1:N, y, color="black")
    grid("on")
    ylabel(L"Temperature $(y)$")

    xlabel(L"Time $(t)$")

    tight_layout()
end

function plotLandscape()
    figure(figsize=(6.4, 3.2))

    z_hat = 0.0:0.01:6.0
    y_hat = [temperature(z_k) for z_k in z_hat]
    plot(z_hat, y_hat, color="black")
    grid("on")
    xlabel(L"Position $(z)$")
    ylabel(L"Temperature $(\mathcal{T})$")

    tight_layout()
end

function inspectSnippet(algo::String)
    println(algo[1:488])
    println("\n...\n")
    println(algo[end-131:end])
end

function findMessageIndex(schedule::Schedule, node_id::Symbol, outbound_interface_id::Union{Int64, Symbol})
    condensed_schedule = ForneyLab.condense(ForneyLab.flatten(schedule))
    for (idx, entry) in enumerate(condensed_schedule)
        node = entry.interface.node
        if (node.id == node_id) && (entry.interface == node.i[outbound_interface_id])
            return idx
        end
    end
    
    error("Message $node_id[$outbound_interface_id] could not be found in schedule")
end